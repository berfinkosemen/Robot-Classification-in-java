/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robotprojesi;

import java.util.ArrayList;


/**
 *
 * @author berfi
 */
public interface Robot {
    public void toplamSureHesaplama(); 
     int [] dizisag = new int [10];
     int [] dizisol = new int [10];
     int [] diziyukari = new int [10];
     int [] diziasagi = new int [10];
}
